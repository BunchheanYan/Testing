﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_10_connect_WIth_SQl
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'northwindDataSet.Alphabetical_list_of_products' table. You can move, or remove it, as needed.
           // this.alphabetical_list_of_productsTableAdapter.Fill(this.northwindDataSet.Alphabetical_list_of_products);

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.categoriesTableAdapter.FillBy(this.northwindDataSet.Categories);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void toolStripProgressBar1_Click(object sender, EventArgs e)
        {

        }
    }
}
