﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.OleDb;

namespace Week_10_connect_WIth_SQl
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        // Define the SqlConnection and other required objects
        private SqlConnection conn;
        private SqlDataAdapter daCategories;
        private SqlDataAdapter daProducts;
        private DataSet ds = new DataSet();
        private BindingSource bsProducts = new BindingSource();
        private BindingSource bsCategories = new BindingSource();

        private void Form2_Load(object sender, EventArgs e)
        {
            // Define the connection string
            string connectionString = @"Data Source=CHHEANG\MSSQLSERVER01;Initial Catalog=Northwind;User ID=chheang;Password=chheang;TrustServerCertificate=True";

            // Initialize the connection
            conn = new SqlConnection(connectionString);

            try
            {
                // Open the connection
                conn.Open();

                // Load data from the Categories table
                string sqlCategories = "SELECT CategoryID, CategoryName FROM Categories";
                daCategories = new SqlDataAdapter(sqlCategories, conn);
                daCategories.Fill(ds, "Categories");

                // Load data from the Products table
                string sqlProducts = "SELECT ProductID, ProductName, CategoryID, UnitPrice, UnitsInStock FROM Products";
                daProducts = new SqlDataAdapter(sqlProducts, conn);
                SqlCommandBuilder cbProducts = new SqlCommandBuilder(daProducts);
                daProducts.Fill(ds, "Products");

                // Set up DataRelation between Categories and Products
                DataRelation relation = new DataRelation("CategoryProducts",
                    ds.Tables["Categories"].Columns["CategoryID"],
                    ds.Tables["Products"].Columns["CategoryID"]);
                ds.Relations.Add(relation);

                // Set up BindingSources
                bsCategories.DataSource = ds;
                bsCategories.DataMember = "Categories";

                bsProducts.DataSource = bsCategories;
                bsProducts.DataMember = "CategoryProducts";

                // Bind data to ComboBox
                cboCategories.DataSource = bsCategories;
                cboCategories.DisplayMember = "CategoryName";
                cboCategories.ValueMember = "CategoryID";

                // Bind data to DataGridView
               // dataGridView.DataSource = bsProducts;

                // Bind data to Labels
                lblProductID.DataBindings.Add("Text", bsProducts, "ProductID");
                lblProductName.DataBindings.Add("Text", bsProducts, "ProductName");

                // Update record label
                UpdateRecordLabel();

                // Handle events for navigation
                bsProducts.PositionChanged += BsProducts_PositionChanged;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // Close the connection
                if (conn.State == ConnectionState.Open)
                    conn.Close();
            }


        }
        private void BsProducts_PositionChanged(object sender, EventArgs e)
        {
            UpdateRecordLabel();
        }

        private void UpdateRecordLabel()
        {
            lblRecords.Text = $"Record: {bsProducts.Position + 1} of {bsProducts.Count}";
        }

        private void cboCategories_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
