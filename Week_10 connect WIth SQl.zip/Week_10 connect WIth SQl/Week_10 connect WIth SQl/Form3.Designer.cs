﻿namespace Week_10_connect_WIth_SQl
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.ProductID = new System.Windows.Forms.Label();
            this.Company = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblCustomerID = new System.Windows.Forms.TextBox();
            this.lblCompanyName = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.TextBox();
            this.cboCustomerID = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // ProductID
            // 
            resources.ApplyResources(this.ProductID, "ProductID");
            this.ProductID.Name = "ProductID";
            // 
            // Company
            // 
            resources.ApplyResources(this.Company, "Company");
            this.Company.Name = "Company";
            // 
            // Address
            // 
            resources.ApplyResources(this.Address, "Address");
            this.Address.Name = "Address";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // lblCustomerID
            // 
            resources.ApplyResources(this.lblCustomerID, "lblCustomerID");
            this.lblCustomerID.Name = "lblCustomerID";
            // 
            // lblCompanyName
            // 
            resources.ApplyResources(this.lblCompanyName, "lblCompanyName");
            this.lblCompanyName.Name = "lblCompanyName";
            // 
            // lblAddress
            // 
            resources.ApplyResources(this.lblAddress, "lblAddress");
            this.lblAddress.Name = "lblAddress";
            // 
            // cboCustomerID
            // 
            resources.ApplyResources(this.cboCustomerID, "cboCustomerID");
            this.cboCustomerID.FormattingEnabled = true;
            this.cboCustomerID.Name = "cboCustomerID";
            // 
            // Form3
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.Controls.Add(this.cboCustomerID);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.lblCompanyName);
            this.Controls.Add(this.lblCustomerID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.Company);
            this.Controls.Add(this.ProductID);
            this.Name = "Form3";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ProductID;
        private System.Windows.Forms.Label Company;
        private System.Windows.Forms.Label Address;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox lblCustomerID;
        private System.Windows.Forms.TextBox lblCompanyName;
        private System.Windows.Forms.TextBox lblAddress;
        private System.Windows.Forms.ComboBox cboCustomerID;
    }
}