﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.SqlClient;
namespace Week_10_connect_WIth_SQl
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection();
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        private void Form3_Load(object sender, EventArgs e)
        {
            // Define the connection string
            
            string connectionString = @"Data Source=CHHEANG\MSSQLSERVER01;Initial Catalog=Northwind;User ID=chheang;Password=chheang;";

            try
            {
                // Initialize the connection object with the connection string
                conn = new SqlConnection(connectionString);

                // Open the connection
                conn.Open();

                // Define the SQL query to select all data from the Customers table
                string sqlCustomers = "SELECT * FROM Customers";

                // Initialize the SqlDataAdapter with the query and connection
                da = new SqlDataAdapter(sqlCustomers, conn);

                // Fill the DataSet with the data from the Customers table
                da.Fill(ds, "Customers");

                // Check if the DataTable contains data
                if (ds.Tables["Customers"].Rows.Count > 0)
                {
                    // Set up the BindingSource to manage the data binding
                    BindingSource bs = new BindingSource();
                    bs.DataSource = ds.Tables["Customers"];

                    // Bind the data to the ComboBox and Labels
                    cboCustomerID.DataSource = bs;
                    cboCustomerID.DisplayMember = "CustomerID";
                    cboCustomerID.ValueMember = "CustomerID";

                    lblCustomerID.DataBindings.Add("Text", bs, "CustomerID");
                    lblCompanyName.DataBindings.Add("Text", bs, "CompanyName");
                    lblAddress.DataBindings.Add("Text", bs, "Address");

                    MessageBox.Show("Data loaded successfully!");
                }
                else
                {
                    MessageBox.Show("No data found in the Customers table.");
                }
            }
            catch (SqlException sqlEx)
            {
                // Handle SQL Server-specific errors
                MessageBox.Show($"SQL Server error: {sqlEx.Message}");
            }
            catch (Exception ex)
            {
                // Handle general errors
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
            finally
            {
                // Ensure the connection is closed
                if (conn != null && conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }
    }
}
