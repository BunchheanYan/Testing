﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Week_10_connect_WIth_SQl
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            try
            {
                // Retrieve the connection string from the configuration file
                string strConn = ConfigurationManager.ConnectionStrings["Northwind"].ConnectionString;

                // Display the connection string in a message box
                MessageBox.Show(strConn, "Connection String Retrieved");
            }
            catch (Exception ex)
            {
                // Handle any errors that occur while retrieving the connection string
                MessageBox.Show($"An error occurred: {ex.Message}", "Error");
            }
        }
    }
}
