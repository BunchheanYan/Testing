﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_10_connect_WIth_SQl
{
    internal class connect
    {
        public connect() { }
    }
}
